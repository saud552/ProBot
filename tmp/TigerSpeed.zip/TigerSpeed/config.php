<?php

$db = mysqli_connect(
  "localhost",
  "tigerspe_youssef", #اسم المستخدم
  "Klash18722@", #كلمة المرور
  "tigerspe_youssef" #قاعدة البيانات
);


?>