<?php


unlink('error.txt');